# inversionesretailBLZ

Versión académica de Retail20inversiones para el Proyecto Web – Grupo 5 PPS2.

## Etapa 1
Esta versión presenta los ocho componentes definidos para la primera instancia:
1. Introducción
2. Primeros pasos
3. Videos introductorios
4. Monitor de mercado
5. Packs de acciones sugeridos
6. Videos explicativos de instrumentos
7. Encuesta de perfil de inversor
8. Contacto

La lógica está preparada para evolucionar por etapas sin modificar la URL pública del proyecto.

## Publicación con GitHub Pages
Subir `index.html`, `styles.css` y `script.js` a la raíz del repositorio.
Luego ir a Settings > Pages > Deploy from a branch > main / root > Save.
