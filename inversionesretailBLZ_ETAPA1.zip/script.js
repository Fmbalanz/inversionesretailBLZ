const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");

if (menuButton && nav) {
  menuButton.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
  });

  nav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    });
  });
}

document.querySelectorAll(".quiz-options button").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".quiz-options button").forEach(item => item.classList.remove("selected"));
    button.classList.add("selected");
  });
});

document.querySelectorAll(".play-btn, .text-link").forEach(button => {
  button.addEventListener("click", () => {
    alert("Este contenido se incorporará progresivamente en las próximas etapas del proyecto.");
  });
});

const contactForm = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

if (contactForm && formMessage) {
  contactForm.addEventListener("submit", event => {
    event.preventDefault();
    formMessage.textContent = "Formulario de demostración: la conexión de envío se incorporará en una próxima etapa.";
  });
}
